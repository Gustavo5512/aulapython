#Feito Por Marcos Emanuel
#resumidamente polimorfismo é a capacidade de diferentes classes usarem o metodo com o mesmo nome
class vaca:
    def som_animal(self):#mesmo nome
        return "muuuu"#retornara a palavra
class cachorro:
    def som_animal(self):#mas
        return "auau"   
class galo:
    def som_animal(self):#funçoes diferentes
        return "cocorico" 
class calculo:
    def som_animal(self):#extra
        return 123*123 #retornara a multiplicação
roça = [vaca(),cachorro(),galo(),calculo()]#roça recebe as classes
for animais in roça:#para animais tudo que estiver em roça
    print(animais.som_animal())#ira fazer os quatros sons
    #muuuu
    #auau
    #cocorico
    #15129