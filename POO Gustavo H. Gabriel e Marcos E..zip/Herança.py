#Feito por Gabriel
class Animal:
    def falar(self):
        print("O animal faz um som.")

class Cachorro(Animal):
    def falar(self):
        print("Au au!")

class Gato(Animal):
    def falar(self):
        print("Miau!")

# Criando objetos
cachorro = Cachorro()
gato = Gato()

cachorro.falar()
gato.falar()
#Vantagens práticas:

#Reusabilidade de código: Permite que subclasses herdem funcionalidades de classes pai, evitando a duplicação de código.

#Facilidade de expansão: Você pode adicionar novos tipos de comportamento às subclasses sem modificar as classes existentes.

#Hierarquia natural: Permite representar de maneira natural relações entre diferentes tipos de objetos (exemplo: Gato e Cachorro são ambos Animais).