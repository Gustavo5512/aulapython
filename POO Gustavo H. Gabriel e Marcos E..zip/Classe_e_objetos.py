#Feito por Gustavo Henrique
#Uma classe  é um modelo que define as caracteristivas e comportamento de um tipo de objeto. ela descreve as variaveis e funções
#ja o objeto é algo que você cria com base no molde da classe. cada objeto tem função e e variavel
class aluno: #aqui é criado/definido uma classe aluno
    def __init__(self, nome,  idade): #def __init__ é uma função que cria aluno, nome e idade
        self.nome = nome #Guarda o nome do aluno
        self.idade = idade#Guarda a idade
        
        
    def apresentar(self):# essa funçao a seguir faz o aluno "se" Apresentar
        print("Meu nome é ", self.nome)
        print("Tenho ", self.idade," anos")
        
aluno1= aluno('Gustavo', 17)#aqui cria o OBJETO definido de aluno1

aluno2= aluno('ana', 21)#aqui cria o OBJETO definido de aluno2

# a seguir os alunos "se " apresentam
aluno1.apresentar()
aluno2.apresentar()

#Com esses exemplos até Macacos domesticados e portões aprendem poo, Ass: Gustavo Henrique