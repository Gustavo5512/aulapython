#Baixe essa biblioteca Geugres:pip install pillow
from PIL import Image
#Feito por Gustavo Henrique
#Um atributo é uma característica  de uma classe ou objeto. Nele se Guardas informações:
#Ex: um nome;uma idade e etc
#na classe aluno a seguir, podemos ver os dois exemplos de atributo que
# foram citados acima, nome e idade:
class aluno:
    def __init__(self, nome,  idade): 
        self.nome = nome #atributo de nome
        self.idade = idade # eo atributo de idade
        
    # o METODO é uma funçao(def) dentro da classe:
    def apresentar(self):
        #Define o que um objeto pode fazer (ex: calcular, imprimir, modificar atributos)
        #Nele podemos calcular, modificar atributos ou imprimir, como nos dois ex a seguir:
        print("Meu nome é ", self.nome) #ex 1
        print("Tenho ", self.idade," anos") #Ex 2
    
aluno1= aluno('Gustavo', 17)
aluno2= aluno('ana', 21)

aluno1.apresentar()
aluno2.apresentar()
imagem = Image.open("foto.jpg")
imagem.show()
#Com abstração, até um pincher caramelo nomeado de balu conectado via bluetooth vira programador. Ass: Gustavo Henrique