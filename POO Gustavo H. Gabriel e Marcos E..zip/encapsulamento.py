#feito por Gabriel
class ContaBancaria:
    def _init_(self, saldo):
        self.__saldo = saldo  # Atributo privado

    def deposito(self, valor):
        self.__saldo += valor

    def consultar_saldo(self):
        return self.__saldo

# Criando objeto
conta = ContaBancaria(100)
conta.deposito(50)
print(conta.consultar_saldo())  # Acesso controlado ao saldo
#Vantagens práticas:

#Segurança: Protege dados sensíveis (como o saldo) e controla como os dados são manipulados, evitando modificações indesejadas.

#Integridade: Garante que os dados do objeto sejam manipulados apenas de maneira segura e controlada.

#Facilidade na manutenção: Mudanças internas na estrutura de dados podem ser feitas sem afetar o código externo que usa a classe.