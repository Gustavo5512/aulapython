#Feito Por Marcos Emanuel
from abc import ABC, abstractmethod# é utilizado o modulo abc para criar classes abstratas
#abstração é permitir esconder detalhes de implemantação para mostrar o essencial que é a interface
class area(ABC):#abstração permite trabalhar com conceitos mais gerais sem saber como tudo funciona(como um carro)
    @abstractmethod#aqui sera a parte principal
    def calculo_area(self):
        pass
class quadrado(area):#uma subclasse para quadardos(area)
    def __init__(self,largura,altura):
        self.largura = largura
        self.altura = altura
    def calculo_area(self):
        return self.altura*self.largura
class triangulo(area):#triangulo(area)
    def __init__(self,largura,altura):
        self.largura = largura
        self.altura = altura
    def calculo_area(self):
        return(self.largura*self.altura)/2
formas = [quadrado(9, 2),
          triangulo(10, 4)]#definir altura e largura
for forma in formas:
    print(forma.calculo_area())
#com isso a varios beneficios como codigo mais organizado
#da par adiconar mais formas como o trapezio e o circolu
#e padronização usa praticamente a mesma formula